import 'package:flutter/material.dart';
import '../models/news_model.dart';
import '../screens/news_detail_screen.dart';

class NewsCard extends StatelessWidget {
  final News news;

  NewsCard({required this.news});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(10),
      child: ListTile(
        title: Text(news.title, style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(news.content, maxLines: 2, overflow: TextOverflow.ellipsis),
        onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) => NewsDetailScreen(news: news)));
        },
      ),
    );
  }
}
