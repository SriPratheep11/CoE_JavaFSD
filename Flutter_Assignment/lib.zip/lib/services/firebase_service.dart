import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/news_model.dart';

class FirebaseService {
  static final FirebaseFirestore _db = FirebaseFirestore.instance;

  static Future<void> uploadNews(News news) async {
    await _db.collection('news').add(news.toMap());
  }

  static Stream<List<News>> getUploadedNews() {
    return _db.collection('news').snapshots().map((snapshot) {
      return snapshot.docs.map((doc) => News.fromJson(doc.data())).toList();
    });
  }
}
