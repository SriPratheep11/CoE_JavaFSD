import 'package:flutter/material.dart';
import '../services/weather_service.dart';

class WeatherScreen extends StatefulWidget {
  @override
  _WeatherScreenState createState() => _WeatherScreenState();
}

class _WeatherScreenState extends State<WeatherScreen> {
  final WeatherService _weatherService = WeatherService();
  final List<String> cities = ["New York", "London", "Tokyo"];
  List<Map<String, dynamic>> weatherData = [];

  @override
  void initState() {
    super.initState();
    fetchWeatherForCities();
  }

  void fetchWeatherForCities() async {
    List<Map<String, dynamic>> fetchedData = [];
    for (String city in cities) {
      try {
        var data = await _weatherService.fetchWeather(city);
        fetchedData.add(data);
      } catch (e) {
        fetchedData.add({"name": city, "error": "Failed to load"});
      }
    }
    setState(() {
      weatherData = fetchedData;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Weather Updates")),
      body: weatherData.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: weatherData.length,
              itemBuilder: (context, index) {
                final cityWeather = weatherData[index];

                if (cityWeather.containsKey("error")) {
                  return ListTile(
                    title: Text(cityWeather["name"], style: TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text(cityWeather["error"]),
                  );
                }

                return Card(
                  margin: EdgeInsets.all(10),
                  child: ListTile(
                    leading: Icon(Icons.wb_sunny, color: Colors.orange),
                    title: Text(cityWeather["name"], style: TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text(
                      "Temperature: ${cityWeather["main"]["temp"]}°C\n"
                      "Condition: ${cityWeather["weather"][0]["description"]}",
                    ),
                  ),
                );
              },
            ),
    );
  }
}
