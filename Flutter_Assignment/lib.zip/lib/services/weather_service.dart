import 'dart:convert';
import 'package:http/http.dart' as http;

class WeatherService {
  final String apiKey = "e9d818d6079743e4b2170306252603"; // Your API Key
  final List<String> cities = ["New York", "London", "Tokyo"]; // Cities List

  Future<List<Map<String, dynamic>>> fetchWeather() async {
    List<Map<String, dynamic>> weatherData = [];

    for (String city in cities) {
      final url =
          "https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey&units=metric";

      try {
        final response = await http.get(Uri.parse(url));

        if (response.statusCode == 200) {
          weatherData.add(json.decode(response.body));
        } else {
          print("Failed to load weather for $city: ${response.statusCode}");
        }
      } catch (e) {
        print("Error fetching weather for $city: $e");
      }
    }

    return weatherData;
  }
}
