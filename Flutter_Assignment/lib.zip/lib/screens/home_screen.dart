import 'package:flutter/material.dart';
import 'weather_screen.dart';
import 'news_upload_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Locale _currentLocale = Locale('en'); // Default language: English
  String _title = "News Reader";
  String _uploadNews = "Upload News";
  String _checkWeather = "Check Weather";

  List<Map<String, String>> newsList = [
    {"title": "CSK vs RR", "content": "Today match is happening in Rajasthan"},
    {"title": "TVM Meeting", "content": "TVK First General meeting was held successfully in Chennai"},
  ];

  void addNews(String title, String content) {
    setState(() {
      newsList.insert(0, {"title": title, "content": content});
    });
  }

  void _changeLanguage(Locale locale) {
    setState(() {
      _currentLocale = locale;

      if (locale.languageCode == 'en') {
        _title = "News Reader";
        _uploadNews = "Upload News";
        _checkWeather = "Check Weather";
      } else if (locale.languageCode == 'es') {
        _title = "Lector de Noticias";
        _uploadNews = "Subir Noticias";
        _checkWeather = "Ver Clima";
      } else if (locale.languageCode == 'ta') {
        _title = "செய்தி வாசிப்பு";
        _uploadNews = "செய்தியை பதிவேற்றவும்";
        _checkWeather = "வானிலை பார்க்க";
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_title),
        actions: [
          IconButton(
            icon: Icon(Icons.language),
            tooltip: 'Change Language',
            onPressed: () {
              _showLanguageDialog(context);
            },
          ),
          IconButton(
            icon: Icon(Icons.add),
            tooltip: _uploadNews,
            onPressed: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => NewsUploadScreen()),
              );

              if (result != null) {
                addNews(result['title'], result['content']);
              }
            },
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: newsList.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.all(10),
            child: ListTile(
              title: Text(
                newsList[index]['title']!,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(newsList[index]['content']!),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => WeatherScreen()),
          );
        },
        child: Icon(Icons.cloud),
        tooltip: _checkWeather,
      ),
    );
  }

  void _showLanguageDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Choose Language"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _languageOption("English", Locale('en')),
              _languageOption("Español", Locale('es')),
              _languageOption("தமிழ்", Locale('ta')),
            ],
          ),
        );
      },
    );
  }

  Widget _languageOption(String langName, Locale locale) {
    return ListTile(
      title: Text(langName),
      onTap: () {
        _changeLanguage(locale);
        Navigator.pop(context);
      },
    );
  }
}
