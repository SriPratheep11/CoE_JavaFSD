import 'package:flutter/material.dart';

class NewsUploadScreen extends StatefulWidget {
  @override
  _NewsUploadScreenState createState() => _NewsUploadScreenState();
}

class _NewsUploadScreenState extends State<NewsUploadScreen> {
  final TextEditingController titleController = TextEditingController();
  final TextEditingController contentController = TextEditingController();

  void _submitNews() {
    if (titleController.text.isNotEmpty && contentController.text.isNotEmpty) {
      Navigator.pop(context, {
        "title": titleController.text,
        "content": contentController.text,
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Upload News")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(controller: titleController, decoration: InputDecoration(labelText: "Title")),
            TextField(controller: contentController, decoration: InputDecoration(labelText: "Content")),
            SizedBox(height: 20),
            ElevatedButton(onPressed: _submitNews, child: Text("Submit News")),
          ],
        ),
      ),
    );
  }
}
