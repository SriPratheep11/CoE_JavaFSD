import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/news_model.dart';

class ApiService {
  static const String _apiKey = "1add3e108bc84a24a4e99b31058e5427"; 
  static const String _baseUrl = "https://newsapi.org/v2/top-headlines?country=us&apiKey=$_apiKey";

  Future<List<NewsArticle>> fetchNews() async {
    try {
      final response = await http.get(Uri.parse(_baseUrl));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final List articles = data['articles'];
        return articles.map((article) => NewsArticle.fromJson(article)).toList();
      } else {
        throw Exception("Failed to load news");
      }
    } catch (e) {
      print("Error fetching news: $e");
      return [];
    }
  }
}
